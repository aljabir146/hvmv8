import { execSync } from 'child_process';
import fs from 'fs';

async function setup() {
  console.log("Checking if pip is already active...");
  try {
    const check = execSync('python3 -m pip --version', { encoding: 'utf-8' });
    console.log("Pip is active:", check.trim());
    return;
  } catch (e) {}

  console.log("Downloading get-pip.py...");
  const res = await fetch('https://bootstrap.pypa.io/get-pip.py');
  if (!res.ok) {
    throw new Error("Failed to download get-pip.py");
  }
  const content = await res.text();
  fs.writeFileSync('get-pip.py', content);
  console.log("Downloaded get-pip.py.");

  console.log("Installing pip...");
  execSync('python3 get-pip.py --user', { stdio: 'inherit' });
  console.log("Pip installed successfully!");

  console.log("Installing requirements...");
  // Let's find python user path binary of pip if not in standard PATH
  // Usually it is ~/.local/bin/pip or python3 -m pip
  execSync('python3 -m pip install -r hvm/requirements.txt --user', { stdio: 'inherit' });
  console.log("All requirements installed successfully!");
}

setup().catch(err => {
  console.error("Setup failed:", err);
});
