import { execSync } from 'child_process';

try {
  const pipCheck = execSync('python3 -m pip --version', { encoding: 'utf-8' });
  console.log('Pip mode check:', pipCheck.trim());
} catch (e: any) {
  console.log('Error pip mode:', e.message);
}

try {
  const requirements = execSync('cat hvm/requirements.txt', { encoding: 'utf-8' });
  console.log('hvm/requirements.txt:\n', requirements);
} catch (e: any) {
  console.log('Error elements:', e.message);
}
