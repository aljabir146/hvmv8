import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';

console.log("Starting TigerHost Hybrid Node-Python Server...");

// 1. Activate the master SQLite database first
try {
  console.log("Activating database...");
  const pythonProc = spawn('python3', [path.join(process.cwd(), 'hvm', 'activate_db.py')], { stdio: 'inherit' });
  pythonProc.on('exit', (code) => {
    console.log(`Database activation finished with code: ${code}`);
  });
} catch (e: any) {
  console.error("Error launching database activation:", e.message);
}

// 2. Spawn the python backend server (runs on port 5000)
console.log("Spawning Python Flask backend (tigerhost)...");
const pythonServer = spawn('python3', [path.join(process.cwd(), 'hvm', 'hvm.py')], {
  stdio: 'pipe',
  env: {
    ...process.env,
    PORT: '5000'
  }
});

pythonServer.stdout.on('data', (data) => {
  console.log(`[Python Stdout]: ${data.toString().trim()}`);
});

pythonServer.stderr.on('data', (data) => {
  console.error(`[Python Stderr]: ${data.toString().trim()}`);
});

pythonServer.on('close', (code) => {
  console.log(`Python server crashed or exited with code ${code}`);
});

// 3. Setup Express Router to proxy to Python
const app = express();
const PORT = 3000; // MUST be 3000

// Setup transparent proxy middleware targeting localhost:5000
const pythonProxy = createProxyMiddleware({
  target: 'http://127.0.0.1:5000',
  changeOrigin: true,
  ws: true, // enable WebSockets proxying for Flask-SocketIO
  logger: console,
  on: {
    error: (err, req, res: any) => {
      console.error('Proxy Error:', err);
      if (res && res.writeHead && !res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
      }
      if (res && typeof res.end === 'function') {
        res.end('TigerHost web gateway is booting, please refresh in a moment...');
      }
    }
  }
});

// Use proxy for all incoming requests (API, Assets, templates, etc.)
app.use('/', pythonProxy);

// Start listening on port 3000
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`Gateway proxy server listening on http://0.0.0.0:${PORT}`);
});

// Setup upgrade handler for pure WS upgrade requests
server.on('upgrade', (req, socket, head) => {
  console.log('Upgrading request for socket.io/websocket connection to localhost:5000');
  // Pass to proxy
  (pythonProxy as any).upgrade(req, socket, head);
});
