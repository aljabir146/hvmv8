import fs from 'fs';
import path from 'path';
import AdmZip from 'adm-zip';

async function downloadAndExtract() {
  const url = 'https://raw.githubusercontent.com/aljabir146/hvmv8/main/hvm%20v8.zip';
  console.log(`Downloading zip from ${url}...`);

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download zip: ${response.statusText}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  const zipPath = path.join(process.cwd(), 'hvm_v8.zip');

  fs.writeFileSync(zipPath, buffer);
  console.log(`Downloaded zip to ${zipPath} (${buffer.length} bytes).`);

  console.log('Extracting zip...');
  const zip = new AdmZip(zipPath);
  zip.extractAllTo(process.cwd(), true);

  console.log('Extraction complete! Checking directory contents...');
  const files = fs.readdirSync(process.cwd());
  console.log('Root directory contents after download:', files);
}

downloadAndExtract().catch((err) => {
  console.error('Error downloading and extracting:', err);
});
