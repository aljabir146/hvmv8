import fs from 'fs';
import path from 'path';

function walk(dir: string) {
  try {
    const list = fs.readdirSync(dir);
    for (const file of list) {
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
         console.log("Dir:", fullPath);
         walk(fullPath);
      } else {
         console.log("File:", fullPath, stat.size);
      }
    }
  } catch (e) {
    console.log("Error walking", dir, e);
  }
}

console.log("Listing hvm folder recursively:");
walk('hvm');
console.log("Listing license-tool.py contents:");
try {
  console.log(fs.readFileSync('license-tool.py', 'utf-8').slice(0, 1000));
} catch (e) {}
