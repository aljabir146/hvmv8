import fs from 'fs';
import path from 'path';

const searchDir = 'hvm';

function walk(dir: string, callback: (filePath: string) => void) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      if (file !== 'node_modules' && file !== '.git') {
        walk(fullPath, callback);
      }
    } else {
      callback(fullPath);
    }
  }
}

console.log("Checking for 'fetch' assignments in: " + searchDir);

const patterns = [
  /\.fetch\s*=/i,
  /window\[['"]fetch['"]\]\s*=/i,
  /fetch\s*=\s*/i,
];

walk(searchDir, (filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  if (['.html', '.js', '.py'].includes(ext)) {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
      // Ignore comments or normal fetch function calls
      if (line.includes('//') || line.includes('/*')) return;
      if (line.includes('fetch(') || line.includes('await fetch')) return;
      
      patterns.forEach(pat => {
        if (pat.test(line)) {
          console.log(`Match in ${filePath}:${idx + 1} -> ${line.trim()}`);
        }
      });
    });
  }
});

console.log("Check finished.");
