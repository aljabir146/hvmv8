import sqlite3
import uuid
import datetime
import os

print("Running Python-based SQLite3 database activation...")

dbs = ['hvm/tigerhost.db', 'tigerhost.db']
for dest_db in dbs:
    if dest_db == 'hvm/tigerhost.db' and not os.path.exists(dest_db):
        if os.path.exists('hvm/hvm.db'):
            import shutil
            shutil.copy('hvm/hvm.db', dest_db)
            print(f"Copied hvm/hvm.db to {dest_db}")
        else:
            print("hvm/hvm.db does not exist!")

    try:
        conn = sqlite3.connect(dest_db)
        cur = conn.cursor()
        cur.execute('DELETE FROM license')
        
        now_str = str(datetime.datetime.now())
        machine_id = str(uuid.getnode())
        
        cur.execute('''
            INSERT INTO license (
                id, 
                license_key, 
                activated, 
                activated_at, 
                activated_by, 
                machine_id, 
                created_at
            ) VALUES (1, "HVMP-VT4H-NW7T-NTV3-PHLL-6358", 1, ?, "admin", ?, ?)
        ''', (now_str, machine_id, now_str))
        
        conn.commit()
        print(f"Success: Injected master license into {dest_db}.")
        
        # Let's inspect
        cur.execute("SELECT * FROM license")
        row = cur.fetchone()
        print(f"Current license record in {dest_db}:", row)
        
        conn.close()
    except Exception as e:
        print(f"Database modification failed for {dest_db}:", e)
