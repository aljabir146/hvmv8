import fs from 'fs';
import path from 'path';

function walk(dir: string, callback: (filePath: string) => void) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      if (file !== 'node_modules' && file !== '.git') {
        walk(fullPath, callback);
      }
    } else {
      callback(fullPath);
    }
  }
}

console.log("Checking entire project for 'fetch' reassignments...");

const patterns = [
  /\.fetch\s*=/i,
  /window\[['"]fetch['"]\]\s*=/i,
  /\bfetch\s*=\s*/i,
];

walk('.', (filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  if (['.html', '.js', '.py', '.ts', '.css'].includes(ext)) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content.split('\n');
      lines.forEach((line, idx) => {
        if (line.includes('//') || line.trim().startsWith('*') || line.trim().startsWith('/*')) return;
        patterns.forEach(pat => {
          if (pat.test(line)) {
            console.log(`Match in ${filePath}:${idx + 1} -> ${line.trim()}`);
          }
        });
      });
    } catch(e) {}
  }
});

console.log("Check finished.");
