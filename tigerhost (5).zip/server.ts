import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { spawn, spawnSync, execSync } from 'child_process';
import path from 'path';
import fs from 'fs';

console.log("Starting TigerHost Hybrid Node-Python Server...");

// Self-healing Python environment check
function ensurePythonDeps() {
  console.log("Verifying Python dependency imports...");
  try {
    // Try importing all the requirements
    execSync('python3 -c "import requests, flask, flask_socketio, gevent, geventwebsocket, paramiko, cryptography, bcrypt"', { stdio: 'ignore' });
    console.log("Python base dependencies are healthy and satisfied.");
  } catch (err) {
    console.log("Python dependencies or pip are missing. Initiating self-healing...");

    const getPipPath = path.join(process.cwd(), 'get-pip.py');
    if (!fs.existsSync(getPipPath)) {
      console.log("Downloading get-pip.py via curl...");
      try {
        execSync(`curl -sS https://bootstrap.pypa.io/get-pip.py -o "${getPipPath}"`, { stdio: 'inherit' });
      } catch (e: any) {
        console.error("Failed to download get-pip.py via curl:", e.message);
      }
    }

    // Check if pip is active
    let pipReady = false;
    try {
      execSync('python3 -m pip --version', { stdio: 'ignore' });
      pipReady = true;
      console.log("Pip is already available.");
    } catch (e) {
      console.log("Installing pip...");
      try {
        execSync(`python3 "${getPipPath}"`, { stdio: 'inherit' });
        pipReady = true;
      } catch (err2: any) {
        console.error("Failed to install pip globally, trying with --user...", err2.message);
        try {
          execSync(`python3 "${getPipPath}" --user`, { stdio: 'inherit' });
          pipReady = true;
        } catch (err3: any) {
          console.error("All pip installation attempts failed:", err3.message);
        }
      }
    }

    if (pipReady) {
      const reqPath = path.join(process.cwd(), 'hvm', 'requirements.txt');
      console.log("Running pip install for requirements.txt...");
      try {
        execSync(`python3 -m pip install -r "${reqPath}"`, { stdio: 'inherit' });
        console.log("Requirements installed successfully!");
      } catch (err2: any) {
        console.warn("Global pip install failed. Trying with --break-system-packages...", err2.message);
        try {
          execSync(`python3 -m pip install -r "${reqPath}" --break-system-packages`, { stdio: 'inherit' });
          console.log("Requirements installed successfully with --break-system-packages!");
        } catch (err3: any) {
          console.error("Failed to install requirements:", err3.message);
        }
      }
    } else {
      console.error("Skipping dependency installation because pip could not be installed.");
    }
  }
}

// Ensure python ecosystem is healthy
ensurePythonDeps();

// 1. Activate the master SQLite database first (synchronously to avoid race conditions)
try {
  console.log("Activating database...");
  const result = spawnSync('python3', [path.join(process.cwd(), 'hvm', 'activate_db.py')], { stdio: 'inherit' });
  console.log(`Database activation finished with exit code: ${result.status}`);
} catch (e: any) {
  console.error("Error launching database activation:", e.message);
}

// 2. Spawn the python backend server (runs on port 5000)
console.log("Spawning Python Flask backend (tigerhost)...");
const pythonServer = spawn('python3', [path.join(process.cwd(), 'hvm', 'hvm.py')], {
  stdio: 'pipe',
  env: {
    ...process.env,
    PORT: '5000'
  }
});

pythonServer.stdout.on('data', (data) => {
  console.log(`[Python Stdout]: ${data.toString().trim()}`);
});

pythonServer.stderr.on('data', (data) => {
  console.error(`[Python Stderr]: ${data.toString().trim()}`);
});

pythonServer.on('close', (code) => {
  console.log(`Python server crashed or exited with code ${code}`);
});

// 3. Setup Express Router to proxy to Python
const app = express();
const PORT = 3000; // MUST be 3000

// Setup transparent proxy middleware targeting localhost:5000
const pythonProxy = createProxyMiddleware({
  target: 'http://127.0.0.1:5000',
  changeOrigin: true,
  ws: true, // enable WebSockets proxying for Flask-SocketIO
  logger: console,
  on: {
    error: (err, req, res: any) => {
      console.error('Proxy Error:', err);
      if (res && res.writeHead && !res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
      }
      if (res && typeof res.end === 'function') {
        res.end('TigerHost web gateway is booting, please refresh in a moment...');
      }
    }
  }
});

// Use proxy for all incoming requests (API, Assets, templates, etc.)
app.use('/', pythonProxy);

// Start listening on port 3000
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`Gateway proxy server listening on http://0.0.0.0:${PORT}`);
});

// Setup upgrade handler for pure WS upgrade requests
server.on('upgrade', (req, socket, head) => {
  console.log('Upgrading request for socket.io/websocket connection to localhost:5000');
  // Pass to proxy
  (pythonProxy as any).upgrade(req, socket, head);
});
