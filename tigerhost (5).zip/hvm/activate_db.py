import sqlite3
import uuid
import datetime
import os
import shutil

print("Running Python-based SQLite3 database activation and self-healing...")

def is_db_healthy(db_path):
    if not os.path.exists(db_path):
        return False
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute("PRAGMA integrity_check;")
        res = cur.fetchone()[0]
        conn.close()
        return res == "ok"
    except Exception:
        return False

# 1. Identify healthy database source
healthy_source = None
possible_sources = ['tigerhost.db', 'hvm/tigerhost.db', 'hvm/hvm.db']

for path in possible_sources:
    if is_db_healthy(path):
        healthy_source = path
        print(f"Found healthy database source: {path}")
        break

# 2. Check and self-heal
dbs = ['hvm/tigerhost.db', 'tigerhost.db', 'hvm/hvm.db']
for dest_db in dbs:
    if is_db_healthy(dest_db):
        print(f"Database {dest_db} is healthy.")
    else:
        print(f"Database {dest_db} is missing or malformed/corrupted.")
        if os.path.exists(dest_db):
            try:
                os.remove(dest_db)
                print(f"Deleted malformed database file: {dest_db}")
            except Exception as e:
                print(f"Failed to delete malformed database file {dest_db}: {e}")
                
        if healthy_source and healthy_source != dest_db:
            try:
                shutil.copy(healthy_source, dest_db)
                print(f"Successfully healed {dest_db} using source {healthy_source}.")
            except Exception as e:
                print(f"Failed to copy and heal {dest_db}: {e}")
        else:
            print(f"No healthy backup source found or applicable. {dest_db} is left to be created clean and fresh by SQLite.")

# 3. Inject license into all healthy targets
for dest_db in dbs:
    try:
        conn = sqlite3.connect(dest_db)
        cur = conn.cursor()
        
        # Ensure license table exists
        cur.execute('''
            CREATE TABLE IF NOT EXISTS license (
                id INTEGER PRIMARY KEY,
                license_key TEXT,
                activated INTEGER,
                activated_at TEXT,
                activated_by TEXT,
                machine_id TEXT,
                created_at TEXT
            )
        ''')
        
        cur.execute('DELETE FROM license')
        
        now_str = str(datetime.datetime.now())
        machine_id = str(uuid.getnode())
        
        cur.execute('''
            INSERT INTO license (
                id, 
                license_key, 
                activated, 
                activated_at, 
                activated_by, 
                machine_id, 
                created_at
            ) VALUES (1, "HVMP-VT4H-NW7T-NTV3-PHLL-6358", 1, ?, "admin", ?, ?)
        ''', (now_str, machine_id, now_str))
        
        conn.commit()
        print(f"Success: Injected master license into {dest_db}.")
        
        # Verify
        cur.execute("SELECT * FROM license")
        row = cur.fetchone()
        print(f"Current license record in {dest_db}:", row)
        
        conn.close()
    except Exception as e:
        print(f"Database modification/activation failed for {dest_db}:", e)
